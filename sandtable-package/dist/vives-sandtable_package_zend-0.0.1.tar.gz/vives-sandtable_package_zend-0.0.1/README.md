<!-- Aan te vullen -->

To do's als functionaliteit toegevoegd is:

in Command line - in sandtable-package directory:
- python3 -m pip install --upgrade build
- python3 -m build
- python3 -m pip install --upgrade twine
-  python3 twine upload dist/*
    * username: __token__
    * password: pypi-AgENdGVzdC5weXBpLm9yZwIkZGNjOGRjZmQtZTU0Zi00NTZjLWExNDMtMzJmZmUxOTg3YTQ2AAIleyJwZXJtaXNzaW9ucyI6ICJ1c2VyIiwgInZlcnNpb24iOiAxfQAABiCsvO7rv3YVOGm2k6pd62lKr02I-99iFrdBsx0_O1GP1g


In command line van interface directory:
- python3 -m pip install vives-sandtable_package_zend

In main.py van de server: from vives-sandtable_package_zend import [klassenaam]